import React, { useState, useEffect } from 'react';
import { EducationLevel, PedagogyType, GraduateDimension, PancaCinta, RPMFormData } from '../types';
import { Loader2, Info, User, BookOpen, Clock, ArrowDownCircle } from 'lucide-react';

interface Props {
  onSubmit: (data: RPMFormData) => void;
  isLoading: boolean;
}

const LOCAL_STORAGE_KEY = 'rpmFormDataDraft';

const initialFormData: RPMFormData = {
  schoolName: '',
  teacherName: '',
  teacherNIP: '',
  principalName: '',
  principalNIP: '',
  city: '',
  level: EducationLevel.SD,
  gradeClass: '',
  subject: '',
  cp: '',
  tp: '',
  material: '',
  meetingCount: 1,
  duration: '',
  pedagogies: [PedagogyType.InkuiriDiscovery],
  dimensions: [],
  pancaCinta: [],
};

// Helper component for Labels with Tooltips
const LabelWithTooltip = ({ label, tooltip }: { label: string; tooltip: string }) => (
  <div className="flex items-center gap-2 mb-1">
    <label className="block text-sm font-bold text-gray-700">
      {label}
    </label>
    <div className="group relative flex items-center">
      <Info size={14} className="text-gray-400 hover:text-primary transition-colors cursor-help" />
      <div className="pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity absolute z-50 bottom-full left-1/2 -translate-x-1/2 mb-2 w-56 p-2 bg-gray-800 text-white text-xs rounded-md shadow-xl text-center leading-relaxed">
        {tooltip}
        {/* Arrow for tooltip */}
        <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-gray-800"></div>
      </div>
    </div>
  </div>
);

// Helper function to generate colorful input classes
const getColorClass = (color: 'blue' | 'sky' | 'teal' | 'emerald' | 'green' | 'lime' | 'indigo' | 'violet' | 'purple' | 'fuchsia' | 'pink' | 'rose' | 'orange' | 'amber') => {
  const base = "w-full rounded-md shadow-sm p-2.5 border text-black transition-all duration-200 outline-none";
  const colors = {
    blue: "border-blue-200 bg-blue-50 focus:border-blue-500 focus:ring-2 focus:ring-blue-200",
    sky: "border-sky-200 bg-sky-50 focus:border-sky-500 focus:ring-2 focus:ring-sky-200",
    teal: "border-teal-200 bg-teal-50 focus:border-teal-500 focus:ring-2 focus:ring-teal-200",
    emerald: "border-emerald-200 bg-emerald-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200",
    green: "border-green-200 bg-green-50 focus:border-green-500 focus:ring-2 focus:ring-green-200",
    lime: "border-lime-200 bg-lime-50 focus:border-lime-500 focus:ring-2 focus:ring-lime-200",
    indigo: "border-indigo-200 bg-indigo-50 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200",
    violet: "border-violet-200 bg-violet-50 focus:border-violet-500 focus:ring-2 focus:ring-violet-200",
    purple: "border-purple-200 bg-purple-50 focus:border-purple-500 focus:ring-2 focus:ring-purple-200",
    fuchsia: "border-fuchsia-200 bg-fuchsia-50 focus:border-fuchsia-500 focus:ring-2 focus:ring-fuchsia-200",
    pink: "border-pink-200 bg-pink-50 focus:border-pink-500 focus:ring-2 focus:ring-pink-200",
    rose: "border-rose-200 bg-rose-50 focus:border-rose-500 focus:ring-2 focus:ring-rose-200",
    orange: "border-orange-200 bg-orange-50 focus:border-orange-500 focus:ring-2 focus:ring-orange-200",
    amber: "border-amber-200 bg-amber-50 focus:border-amber-500 focus:ring-2 focus:ring-amber-200",
  };
  return `${base} ${colors[color]}`;
};

const RPMForm: React.FC<Props> = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState<RPMFormData>(() => {
    try {
      const savedDraft = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (savedDraft) {
        const parsed = JSON.parse(savedDraft);
        return { ...initialFormData, ...parsed };
      }
    } catch (error) {
      console.error("Gagal memuat draf dari localStorage:", error);
    }
    return initialFormData;
  });

  const [activeSection, setActiveSection] = useState('identity');

  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(formData));
      } catch (error) {
        console.error("Gagal menyimpan draf ke localStorage:", error);
      }
    }, 1000);

    return () => {
      clearTimeout(timer);
    };
  }, [formData]);

  useEffect(() => {
    setFormData(prev => {
      const currentLength = prev.pedagogies.length;
      if (prev.meetingCount > currentLength) {
        const diff = prev.meetingCount - currentLength;
        return {
          ...prev,
          pedagogies: [...prev.pedagogies, ...Array(diff).fill(PedagogyType.InkuiriDiscovery)]
        };
      } else if (prev.meetingCount < currentLength) {
        return {
          ...prev,
          pedagogies: prev.pedagogies.slice(0, prev.meetingCount)
        };
      }
      return prev;
    });
  }, [formData.meetingCount]);

  // ScrollSpy Logic
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['identity', 'detail', 'strategy'];
      const scrollPosition = window.scrollY + 180; // Offset for header + sticky nav

      for (const section of sections) {
        const element = document.getElementById(`section-${section}`);
        if (element && element.offsetTop <= scrollPosition) {
          setActiveSection(section);
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleDimensionChange = (dim: string) => {
    setFormData(prev => {
      const exists = prev.dimensions.includes(dim);
      if (exists) {
        return { ...prev, dimensions: prev.dimensions.filter(d => d !== dim) };
      }
      return { ...prev, dimensions: [...prev.dimensions, dim] };
    });
  };

  const handlePancaCintaChange = (val: string) => {
    setFormData(prev => {
      const exists = prev.pancaCinta.includes(val);
      if (exists) {
        return { ...prev, pancaCinta: prev.pancaCinta.filter(d => d !== val) };
      }
      return { ...prev, pancaCinta: [...prev.pancaCinta, val] };
    });
  };

  const handlePedagogyChange = (index: number, value: string) => {
    const newPedagogies = [...formData.pedagogies];
    newPedagogies[index] = value;
    setFormData(prev => ({ ...prev, pedagogies: newPedagogies }));
  };

  const getClassOptions = () => {
    if (formData.level === EducationLevel.SD) return ['1', '2', '3', '4', '5', '6'];
    if (formData.level === EducationLevel.SMP) return ['7', '8', '9'];
    return ['10', '11', '12'];
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(id.replace('section-', ''));
    }
  };

  const navItems = [
    { id: 'section-identity', label: 'Identitas', icon: User, color: 'text-blue-600' },
    { id: 'section-detail', label: 'Detail', icon: BookOpen, color: 'text-purple-600' },
    { id: 'section-strategy', label: 'Strategi', icon: Clock, color: 'text-lime-600' },
  ];

  return (
    <>
      {/* Sticky Navigation Bar */}
      <div className="sticky top-[80px] z-40 bg-white/90 backdrop-blur-md shadow-sm border border-gray-200 rounded-xl px-2 py-2 mb-6 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar md:px-4">
        <div className="flex gap-1 md:gap-2">
            {navItems.map((item) => (
            <button
                key={item.id}
                type="button"
                onClick={() => scrollToSection(item.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap
                ${activeSection === item.id.replace('section-', '') 
                    ? `bg-gray-100 ${item.color} shadow-sm ring-1 ring-gray-200` 
                    : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'}`}
            >
                <item.icon size={16} />
                <span className="hidden sm:inline">{item.label}</span>
            </button>
            ))}
        </div>
        <button
            type="button"
            onClick={() => scrollToSection('section-submit')}
            className="flex items-center gap-2 px-4 py-2 bg-primary/10 text-primary hover:bg-primary hover:text-white rounded-lg text-sm font-bold transition-all whitespace-nowrap ml-2"
        >
            <span>Ke Hasil</span>
            <ArrowDownCircle size={16} />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="bg-white shadow-xl rounded-2xl p-4 md:p-8 space-y-6 md:space-y-8 border border-gray-100">
        
        {/* Section 1: Data Identitas */}
        <div id="section-identity" className="scroll-mt-32 space-y-6">
          <h3 className="text-lg md:text-xl font-bold text-gray-800 border-l-4 border-blue-500 pl-3 flex items-center">
            Data Pendidik & Sekolah
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5">
            <div>
              <LabelWithTooltip label="Nama Satuan Pendidikan *" tooltip="Nama resmi sekolah tempat Anda mengajar (sesuai Dapodik)." />
              <input required name="schoolName" value={formData.schoolName} onChange={handleChange} className={getColorClass('blue')} placeholder="Contoh: SD Negeri 1 Merdeka" />
            </div>
            <div>
              <LabelWithTooltip label="Kota/Kabupaten *" tooltip="Lokasi kota atau kabupaten tempat sekolah berada." />
              <input required name="city" value={formData.city} onChange={handleChange} className={getColorClass('sky')} placeholder="Contoh: Banyuwangi" />
            </div>
            <div>
              <LabelWithTooltip label="Nama Kepala Sekolah *" tooltip="Nama lengkap Kepala Sekolah beserta gelar akademik." />
              <input required name="principalName" value={formData.principalName} onChange={handleChange} className={getColorClass('teal')} />
            </div>
            <div>
              <LabelWithTooltip label="NIP Kepala Sekolah *" tooltip="Nomor Induk Pegawai Kepala Sekolah (jika ada)." />
              <input required name="principalNIP" value={formData.principalNIP} onChange={handleChange} className={getColorClass('emerald')} />
            </div>
            <div>
              <LabelWithTooltip label="Nama Guru *" tooltip="Nama lengkap Anda sebagai guru pengampu mata pelajaran." />
              <input required name="teacherName" value={formData.teacherName} onChange={handleChange} className={getColorClass('indigo')} />
            </div>
            <div>
              <LabelWithTooltip label="NIP Guru *" tooltip="Nomor Induk Pegawai Anda (jika ada/diperlukan)." />
              <input required name="teacherNIP" value={formData.teacherNIP} onChange={handleChange} className={getColorClass('violet')} />
            </div>
          </div>
        </div>

        {/* Section 2: Detail Kelas & Mata Pelajaran */}
        <div id="section-detail" className="scroll-mt-32 space-y-6">
          <h3 className="text-lg md:text-xl font-bold text-gray-800 border-l-4 border-purple-500 pl-3 flex items-center">
              Detail Pembelajaran
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5">
            <div>
              <LabelWithTooltip label="Jenjang *" tooltip="Pilih jenjang pendidikan (SD, SMP, atau SMA)." />
              <select name="level" value={formData.level} onChange={handleChange} className={getColorClass('purple')}>
                {Object.values(EducationLevel).map(l => <option key={l} value={l}>{l}</option>)}
              </select>
            </div>
            <div>
              <LabelWithTooltip label="Kelas *" tooltip="Pilih kelas target untuk pembelajaran ini." />
              <select required name="gradeClass" value={formData.gradeClass} onChange={handleChange} className={getColorClass('fuchsia')}>
                  <option value="">Pilih Kelas</option>
                  {getClassOptions().map(c => <option key={c} value={c}>Kelas {c}</option>)}
              </select>
            </div>
            <div>
              <LabelWithTooltip label="Mata Pelajaran *" tooltip="Nama mata pelajaran yang diampu, misal: IPAS, Matematika, PAI." />
              <input required name="subject" value={formData.subject} onChange={handleChange} className={getColorClass('pink')} placeholder="Contoh: IPAS" />
            </div>
          </div>
          
          <div className="grid grid-cols-1 gap-4 md:gap-5">
              <div>
                  <LabelWithTooltip label="Capaian Pembelajaran (CP) *" tooltip="Salin narasi Capaian Pembelajaran (CP) utuh untuk fase ini dari dokumen kurikulum." />
                  <textarea required rows={3} name="cp" value={formData.cp} onChange={handleChange} className={getColorClass('rose')} placeholder="Salin CP dari kurikulum..." />
              </div>
              <div>
                  <LabelWithTooltip label="Tujuan Pembelajaran (TP) *" tooltip="Turunkan CP menjadi tujuan operasional spesifik yang dapat diukur dan diamati dalam pertemuan ini." />
                  <textarea required rows={3} name="tp" value={formData.tp} onChange={handleChange} className={getColorClass('orange')} placeholder="Rumusan tujuan pembelajaran..." />
              </div>
              <div>
                  <LabelWithTooltip label="Materi Pelajaran *" tooltip="Topik atau sub-bab spesifik yang akan diajarkan." />
                  <input required name="material" value={formData.material} onChange={handleChange} className={getColorClass('amber')} placeholder="Contoh: Rantai Makanan" />
              </div>
          </div>
        </div>

        {/* Section 3: Teknis Pelaksanaan */}
        <div id="section-strategy" className="scroll-mt-32 space-y-6">
          <h3 className="text-lg md:text-xl font-bold text-gray-800 border-l-4 border-lime-500 pl-3 flex items-center">
              Strategi & Waktu
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5">
              <div>
                  <LabelWithTooltip label="Jumlah Pertemuan *" tooltip="Berapa kali pertemuan tatap muka yang dialokasikan untuk materi ini?" />
                  <input required type="number" min="1" max="20" name="meetingCount" value={formData.meetingCount} onChange={handleChange} className={getColorClass('lime')} />
              </div>
              <div>
                  <LabelWithTooltip label="Durasi per Pertemuan *" tooltip="Waktu efektif belajar, contoh: 2 Jam Pelajaran (2 x 35 menit)." />
                  <input required name="duration" value={formData.duration} onChange={handleChange} className={getColorClass('green')} placeholder="Contoh: 2 x 35 menit" />
              </div>
          </div>

          <div className="bg-lime-50/50 p-4 md:p-5 rounded-lg border border-lime-100">
              <LabelWithTooltip label="Praktik Pedagogis per Pertemuan" tooltip="Pilih model pembelajaran yang paling sesuai untuk setiap pertemuan (Inkuiri, PjBL, dll)." />
              {formData.pedagogies.map((pedagogy, idx) => (
                  <div key={idx} className="flex flex-col sm:flex-row sm:items-center gap-2 mb-3">
                      <span className="text-xs font-bold text-gray-600 sm:w-24 uppercase tracking-wider mb-1 sm:mb-0">Pertemuan {idx + 1}</span>
                      <select 
                          value={pedagogy} 
                          onChange={(e) => handlePedagogyChange(idx, e.target.value)} 
                          className="flex-1 rounded-md border-lime-200 bg-white shadow-sm focus:border-lime-500 focus:ring-2 focus:ring-lime-200 p-2.5 border text-sm text-black w-full"
                      >
                          {Object.values(PedagogyType).map(p => <option key={p} value={p}>{p}</option>)}
                      </select>
                  </div>
              ))}
          </div>
          
          <div className="bg-indigo-50/50 p-4 md:p-5 rounded-lg border border-indigo-100">
              <LabelWithTooltip label="Dimensi Lulusan (Pilih yang relevan)" tooltip="Pilih dimensi Profil Pelajar Pancasila atau Kompetensi Lulusan yang ingin dikuatkan." />
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 mt-2">
                  {Object.values(GraduateDimension).map(dim => (
                      <label key={dim} className={`cursor-pointer border p-2.5 rounded-lg text-sm flex items-center gap-2 transition-all shadow-sm ${formData.dimensions.includes(dim) ? 'bg-indigo-100 border-indigo-400 text-indigo-900 font-bold ring-1 ring-indigo-400' : 'hover:bg-white bg-white/80 border-indigo-100 text-gray-700'}`}>
                          <input type="checkbox" checked={formData.dimensions.includes(dim)} onChange={() => handleDimensionChange(dim)} className="rounded text-indigo-600 focus:ring-indigo-500 flex-shrink-0" />
                          <span className="leading-tight">{dim}</span>
                      </label>
                  ))}
              </div>
          </div>

          <div className="bg-rose-50/50 p-4 md:p-5 rounded-lg border border-rose-100">
              <LabelWithTooltip label="5 Panca Cinta (Kemenag RI)" tooltip="Nilai karakter khas madrasah yang diintegrasikan dalam pembelajaran (opsional untuk sekolah umum)." />
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 mt-2">
                  {Object.values(PancaCinta).map(val => (
                      <label key={val} className={`cursor-pointer border p-2.5 rounded-lg text-sm flex items-center gap-2 transition-all shadow-sm ${formData.pancaCinta.includes(val) ? 'bg-rose-100 border-rose-400 text-rose-900 font-bold ring-1 ring-rose-400' : 'hover:bg-white bg-white/80 border-rose-100 text-gray-700'}`}>
                          <input type="checkbox" checked={formData.pancaCinta.includes(val)} onChange={() => handlePancaCintaChange(val)} className="rounded text-rose-600 focus:ring-rose-500 flex-shrink-0" />
                          <span className="leading-tight">{val}</span>
                      </label>
                  ))}
              </div>
          </div>
        </div>

        <div id="section-submit" className="pt-6 scroll-mt-32">
          <button 
            type="submit" 
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-primary to-secondary hover:from-teal-600 hover:to-teal-800 text-white font-bold py-3 md:py-4 px-6 rounded-xl shadow-xl transform transition hover:-translate-y-1 hover:shadow-2xl disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3 text-base md:text-lg"
          >
            {isLoading ? (
              <>
                <Loader2 className="animate-spin w-5 h-5 md:w-6 md:h-6" /> Sedang Menyusun RPM...
              </>
            ) : (
              'Generate Rencana Pembelajaran'
            )}
          </button>
        </div>
      </form>
    </>
  );
};

export default RPMForm;